# BeeNews — Bee the First to Know

A news aggregation website with checked headlines and short summaries that link to the original publishers.

## Sections
AI · GCC · Health & Wellness · Sports & Events · Politics · Cars · UAE Events · Markets · Horoscope

## Features
- Verification labels on every story: Official announcement, Corroborated, Developing, Single source
- "Editor sign-off" flag on health and political stories
- Filters by section, country, date, label and keyword; UAE Events filters by emirate, timing and type
- English, Arabic (right-to-left), French and German
- Markets snapshot: AED exchange rates with a converter, Gulf and US indices, oil and gold
- Mobile-friendly layout, light and dark themes, GSAP scroll animations (off for reduced-motion users)

## Running it
`index.html` is a single self-contained file. Open it in a browser, or host it on any static host
(GitHub Pages, Netlify, Vercel). It loads GSAP from cdnjs and fonts from Google Fonts.

## Content notes
- This is a fixed edition dated 28 October 2026. Stories, rates and events do not update on their own.
- Headlines and summaries are written by BeeNews; full articles and photos remain with their publishers.
- Market figures are a dated snapshot, not live prices, and are not financial advice.
- Arabic, French and German text was translated with AI and should be reviewed by native speakers.
